package spot.QA.stepDef;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import spot.QA.pages.FlightSelectionPage;
import spot.QA.pages.HomePage;
import spot.QA.pages.PassengerDetailsPage;
import spot.QA.pages.ShoppingCartPage;
import spot.QA.utils.DateUtils;
import spot.QA.utils.PropertyFileHandling;
import spot.QA.utils.WebdriverAutomation;

public class BookFlightStepDef {
	WebDriver driver = null;
	public static  final int MAX_WAIT_TIME_SECONDS=40;
	com.aventstack.extentreports.ExtentReports extent ;
	 ExtentHtmlReporter htmlReporter;

	 ExtentTest test;
	 
//	 Pages
	 HomePage homePage;
	 FlightSelectionPage flightSelectionPage;
	 ShoppingCartPage shoppingCartPage;
	 PassengerDetailsPage passengerDetailsPage;
	 
	public  BookFlightStepDef(){
		
		
		//Driver Initialization  
		driver = WebdriverAutomation.getWebDriver(PropertyFileHandling.getPropertyValue("BROWSER", WebdriverAutomation.CONFIG_FILE_PATH));
		
		//Page Initialization 
		homePage=PageFactory.initElements(driver, HomePage.class);
		flightSelectionPage=PageFactory.initElements(driver, FlightSelectionPage.class);
		shoppingCartPage=PageFactory.initElements(driver, ShoppingCartPage.class);
		passengerDetailsPage=PageFactory.initElements(driver, PassengerDetailsPage.class);
		
		
		 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
         Date date = new Date();
         String s = dateFormat.format(date);
         htmlReporter = new ExtentHtmlReporter(PropertyFileHandling.getPropertyValue("RESULTS", WebdriverAutomation.CONFIG_FILE_PATH) +  "Lufthansa_Booking_Results_" + s.toString() + ".html");

         extent  = new com.aventstack.extentreports.ExtentReports();
         extent.attachReporter(htmlReporter);

	}
	
	@Given("^launch app \"(.*?)\"$")
	public void launch_app(String url) throws Throwable {
		
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(url);

		test = extent.createTest("Book Flight", "Book Flight from Lufthansa");

		test.log(Status.INFO, "<span class='label info' style='font-weight:bold;'>" + "Application Started   " + url + "</span>");
	}

	@When("^select from \"([^\"]*)\" and to \"([^\"]*)\" locations$")
	public void select_from_and_to_locations(String source, String Desti) throws Throwable {

		// FROM
		homePage.selectFrom(source);
		
		//TO
		homePage.selectTo(Desti);

	}

	@When("^select one way$")
	public void select_one_way() throws Throwable {
		
		homePage.selectOneWay();

	}

	@When("^enter depart date as twodays from today and one adult with business \"([^\"]*)\" class$")
	public void enter_depart_date_as_twodays_from_today_and_one_adult_with_business_class(String classType)
			throws Throwable {

		homePage.selectDepartingDate();
		String requireDate = DateUtils.getSpecificDateFromToday(2);
		
		driver.findElement(By.xpath("(//button[@aria-label='" + requireDate + "'])[1]")).click();
		homePage.selectTravelDetails();
	
		homePage.selectClassType(classType);
		
		homePage.selectContinue();
	}

	@Then("^Click on Search$")
	public void click_on_Search() throws Throwable {

		homePage.selectSearchFlights();
	}

	@When("^select lowest flight cost and take screenshot$")
	public void select_lowest_flight_cost_and_take_screenshot() throws Throwable {
		
		flightSelectionPage.selectLowetPrice();
		

	}

	@When("^click  on continue$")
	public void click_on_continue() throws Throwable {
		flightSelectionPage.selectContinue();
	}

	@When("^review cart and take screenshot$")
	public void review_cart_and_take_screenshot() throws Throwable {

		
		//From Booking Info
		
		String sDateTimeFromBooking = shoppingCartPage.bookingHeader.getText().toString().trim();
		String sPriceFromBooking = shoppingCartPage.bookingPrice.getText().toString().trim();
		
		/*System.out.println(sDateTimeFromBooking);
		System.out.println(sPriceFromBooking);*/
		
		// From Cart
		String sDateTime = shoppingCartPage.dateTime.getText().toString().trim();
		String sSource = shoppingCartPage.source.getText().toString().trim();
		String sDestination =shoppingCartPage.destination.getText().toString().trim();
		String sPrice = shoppingCartPage.priceFromCart.getText().toString().trim();

		/*System.out.println(sDateTime);
		System.out.println(sSource);
		System.out.println(sDestination);
		System.out.println(sPrice);*/
		
		
		assertResultsAndLog(sDateTimeFromBooking,sDateTime.substring(0, sDateTime.length()-5).trim());
		
		assertResultsAndLog(sDateTimeFromBooking,sSource.split(" ")[0].toString().trim());
		assertResultsAndLog(sDateTimeFromBooking,sDestination.split(" ")[0].toString().trim());
		
		assertResultsAndLog(sPriceFromBooking,sPrice);
		
		
		String screenCartPath=capture(driver,"Cart");
		
		
		test.info("Snapshot below: ", MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir") +"//"+screenCartPath).build());


	}

	@Then("^click on continue again$")
	public void click_on_continue_again() throws Throwable {
		shoppingCartPage.selectContinue();

	}

	@When("^enter passenger details \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\", \"([^\"]*)\" , \"([^\"]*)\" and click on continue$")
	public void enter_passenger_details_and_click_on_continue(String salutation, String fname, String lname, String no,	String mailid) throws Throwable {
		

		// Passenger Details
		passengerDetailsPage.selectSalution(salutation);

		passengerDetailsPage.setFirstName(fname);
		passengerDetailsPage.setLasttName(fname);
		passengerDetailsPage.selectCountryCode("+91 (India)");

		passengerDetailsPage.setPhoneNumber(no);
		passengerDetailsPage.setMail(mailid);

		passengerDetailsPage.selectContinue();
	}

	@Then("^take screenshot of results$")
	public void take_screenshot_of_results() throws Throwable {
		
		String screenPath=capture(driver,"PaymentScreen");
		System.out.println(screenPath);
		test.info("Snapshot below: ", MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir") +"//"+screenPath).build());

		endTestresults();
	}
	
	@Then("^Close Browser$")
	public void close_browser() throws Throwable {
		
		driver.close();
	}
	
	
	
	public void endTestresults(){
		extent.flush();
		
		
	}
	
	public static String capture(WebDriver driver,String sScreenName) throws IOException
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        
        String dest = PropertyFileHandling.getPropertyValue("SCREEN_SHOTS", WebdriverAutomation.CONFIG_FILE_PATH)+sScreenName+".png";
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);        
                     
        return dest;
    }
	
	public void assertResultsAndLog(String expected, String actual){
		if(expected.contains(actual) || expected.equals(actual)){
			test.log(Status.PASS, "<span class='label pass' style='font-weight:bold;'>" + "Booking "+" : &nbsp;"  +expected+" , &nbsp;"   +"Cart"+" : &nbsp;" +actual+ "</span>");
			
		}
		else{
			test.log(Status.FAIL, "<span style='color:red' style='font-weight:bold;'>" + "Booking "+" : &nbsp;"  +expected+" , &nbsp;"   +"Cart"+" : &nbsp;" +actual+ "</span>");
		}



		
		
	}

}
