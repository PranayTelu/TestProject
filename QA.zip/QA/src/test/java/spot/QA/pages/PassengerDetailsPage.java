package spot.QA.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import spot.QA.utils.WebdriverAutomation;

public class PassengerDetailsPage {
	public WebDriver driver;

	@FindBy(xpath = "//button[@id='TOOLBAR_CONTINUE_0']")
	private WebElement btnContinue;

	@FindBy(xpath = "//select[@id='PASSENGERS_ADT_TITLE_0']")
	private WebElement selTitle;

	@FindBy(xpath = "//input[@id='PASSENGERS_ADT_FIRST_NAME_0']")
	private WebElement txtFirstname;

	@FindBy(xpath = "//input[@id='PASSENGERS_ADT_LAST_NAME_0']")
	private WebElement txtLastName;
	
	

	@FindBy(xpath = "//select[@id='CONTACT_DETAILS_PHONE_PHONE_COUNTRY_0']")
	private WebElement selCountryCode;
	
	@FindBy(xpath = "//input[@id='CONTACT_DETAILS_PHONE_PHONE_NUMBER_0']")
	private WebElement txtPhoneNo;
	
	@FindBy(xpath = "//input[@id='CONTACT_DETAILS_EMAIL_0']")
	private WebElement txtEmail;
	
	

	public void selectSalution(String sValue) {
		try {
			waitForVisibility(selTitle);
			Select selectClass = new Select(selTitle);
			selectClass.selectByVisibleText(sValue);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectCountryCode(String sValue) {
		try {
			waitForVisibility(selCountryCode);
			Select selectClass = new Select(selCountryCode);
			selectClass.selectByVisibleText(sValue);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setFirstName(String value) {

		try {

			waitForVisibility(txtFirstname);
			txtFirstname.sendKeys(value);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void setPhoneNumber(String value) {

		try {

			waitForVisibility(txtPhoneNo);
			txtPhoneNo.sendKeys(value);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setMail(String value) {

		try {

			waitForVisibility(txtEmail);
			txtEmail.sendKeys(value);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void setLasttName(String value) {

		try {

			waitForVisibility(txtLastName);
			txtLastName.sendKeys(value);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectContinue() {

		try {
			waitForVisibility(btnContinue);
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", btnContinue);
			btnContinue.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public PassengerDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	private void waitForVisibility(WebElement element) throws Error {
		new WebDriverWait(driver, WebdriverAutomation.MAX_WAIT_TIME_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
	}
}
