package spot.QA.pages;

public class spotQARunner {

}
