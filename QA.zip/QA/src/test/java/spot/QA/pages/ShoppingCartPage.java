package spot.QA.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import spot.QA.utils.WebdriverAutomation;

public class ShoppingCartPage {
	public WebDriver driver;
	
	@FindBy(xpath="//button[@id='TOOLBAR_2_CHECKOUT_0']")
	private WebElement btnContinue;
	
	@FindBy(xpath="//h4[@id='rebook-flight-1']")
	public WebElement bookingHeader;
	
	

	@FindBy(xpath="//span[@id='angular-flight-total-price']")
	public WebElement bookingPrice;
	
	@FindBy(xpath="//*[@id='flight-group-bound-0']/h4/time")
	public WebElement dateTime;
	
	
	@FindBy(xpath="//*[@id='flight-group-bound-0']/p[1]/span[2]")
	public WebElement source;
	
	
	@FindBy(xpath="//*[@id='flight-group-bound-0']/p[2]/span[2]")
	public WebElement destination;
	
	@FindBy(xpath="//*[@id='flights-subtotal']/cart-flights-subtotal-price/span")
	public WebElement priceFromCart;
	
	public ShoppingCartPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
public void selectContinue(){
		
		
		try{
			waitForVisibility(btnContinue);
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", btnContinue);
			btnContinue.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	private void waitForVisibility(WebElement element) throws Error{
        new WebDriverWait(driver, WebdriverAutomation.MAX_WAIT_TIME_SECONDS)
             .until(ExpectedConditions.elementToBeClickable(element));
 }

}
