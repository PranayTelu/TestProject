package spot.QA.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import spot.QA.utils.PropertyFileHandling;
import spot.QA.utils.WebdriverAutomation;

public class HomePage extends WebdriverAutomation {
	public WebDriver driver;
	@FindBy(xpath="//input[@id='flightmanagerFlightsFormOrigin']")
	private  WebElement txtFromFlight;
	
	/*@FindBy(xpath="//*[@id='flightmanagerFlightsFormOriginPopupList']/li")
	private WebElement fromListValue;*/
	
	@FindBy(xpath="//*[@id='flightmanagerFlightsFormOriginPopupList']/li/table/tbody/tr/td[1]")
	private WebElement fromListValue;
	
	
	@FindBy(xpath="//input[@id='flightmanagerFlightsFormDestination']")
	private WebElement txtDestinationFlight;
	
	/*@FindBy(xpath="//*[@id='flightmanagerFlightsFormDestinationPopupList']/li[1]")
	private WebElement toListValue;*/
	
	@FindBy(xpath="//*[@id='flightmanagerFlightsFormDestinationPopupList']/li[1]/table/tbody/tr/td[1]")
	private WebElement toListValue;
	
	
	@FindBy(xpath="//span[text()='One-way']")
	private WebElement chkOneWay;
	
	@FindBy(xpath="//input[@id='flightmanagerFlightsFormOutboundDateDisplay']")
	private WebElement dateDepart;
	

	@FindBy(xpath="//Button[@id='flightmanagerFlightsFormTraveldetailsBtn']")
	private WebElement btnTravelDetails;
	
	
	@FindBy(xpath="//select[@id='traveldetailsCabin']")
	private WebElement selClassType;
	

	@FindBy(xpath="//div[@id='flightmanagerFlightsFormTraveldetailsDialog']//input")
	private WebElement btnContinue;
	
	@FindBy(xpath="//button[text()='Search flights']")
	private WebElement btnSearchFlights;
	
	
	
	public HomePage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void selectFrom(String sFrom){
		String textValue = "";
		try{
			waitForVisibility(txtFromFlight);
			txtFromFlight.sendKeys(sFrom);
			
			textValue=PropertyFileHandling.getPropertyValue(sFrom,CONFIG_FILE_PATH);
			waitForTextToAppear(fromListValue, textValue);
//			waitForVisibility(fromListValue);
//			Thread.sleep(2000);
			fromListValue.click();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectTo(String sTo){
		String textValue = "";
		try{
			waitForVisibility(txtDestinationFlight);
			txtDestinationFlight.sendKeys(sTo);
			textValue=PropertyFileHandling.getPropertyValue(sTo,CONFIG_FILE_PATH);
			waitForTextToAppear(toListValue, textValue);
			/*waitForVisibility(toListValue);
			Thread.sleep(2000);*/
			toListValue.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void selectOneWay(){
		try{
			waitForVisibility(chkOneWay);
			chkOneWay.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	

	public void selectDepartingDate(){
		try{
			waitForVisibility(dateDepart);
			dateDepart.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectTravelDetails(){
		try{
			waitForVisibility(btnTravelDetails);
			btnTravelDetails.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectContinue(){
		try{
			waitForVisibility(btnContinue);
			btnContinue.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectSearchFlights(){
		try{
			waitForVisibility(btnSearchFlights);
			btnSearchFlights.click();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectClassType(String Type){
		try{
			waitForVisibility(selClassType);
			Select selectClass = new Select(selClassType);
			selectClass.selectByVisibleText(Type);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void waitForVisibility(WebElement element) throws Error{
        new WebDriverWait(driver, WebdriverAutomation.MAX_WAIT_TIME_SECONDS)
             .until(ExpectedConditions.elementToBeClickable(element));
 }
	
	private void waitForTextToAppear(WebElement element,String value) throws Error{
        new WebDriverWait(driver, WebdriverAutomation.MAX_WAIT_TIME_SECONDS)
             .until(ExpectedConditions.textToBePresentInElement(element, value));
 }


}
