package spot.QA.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import spot.QA.utils.WebdriverAutomation;

public class FlightSelectionPage {
	public WebDriver driver;

	@FindBy(xpath = "//select[@id='FLIGHTS_FLIGHTS_SORTING_0']")
	private WebElement selSortBy;

	@FindBy(xpath = "(//input[starts-with(@id,'flightRadio_0')])[1]")
	private WebElement rbLowestPrice;

	@FindBy(xpath = "//button[@id='TOOLBAR_CONTINUE_0']")
	private WebElement btnContinue;


	public FlightSelectionPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void sortBy(String sValue) {
		try {
			waitForVisibility(selSortBy);
			Select selectClass = new Select(selSortBy);
			selectClass.selectByVisibleText(sValue);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	public void selectLowetPrice() {

		try {
			sortBy("Price");
			waitForVisibility(rbLowestPrice);
			rbLowestPrice.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectContinue() {

		try {
			waitForVisibility(btnContinue);
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", btnContinue);
			btnContinue.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void waitForVisibility(WebElement element) throws Error {
		new WebDriverWait(driver, WebdriverAutomation.MAX_WAIT_TIME_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
	}
}
