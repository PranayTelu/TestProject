package spot.QA.pages;

public class PaymentDetailsPage {

}
