package spot.QA.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(format={"html:output"},tags={"@BookFlightTickets"},features={"src/test/java/spot/QA/features/"},glue={"spot.QA.stepDef"})
public class spotQARunner {

}
