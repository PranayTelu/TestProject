package spot.QA.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {
	
	public static void main(String a[]){
		try{
//			getSpecificDateFromToday(5);
			/*SimpleDateFormat newDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date MyDate = newDateFormat.parse("28/12/2013");
			newDateFormat.applyPattern("EE d MMM yyyy");
			String MyDate1 = newDateFormat.format(MyDate);
			System.out.println(MyDate1);*/
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public  static  String getSpecificDateFromToday(int nofDays){
		DateFormat dateFormat = new SimpleDateFormat("EE dd.MM.yyyy");
		Date date = new Date();
		Calendar c = Calendar.getInstance(); 
		c.setTime(date); 
		c.add(Calendar.DATE, nofDays);
		date = c.getTime();
		String str=dateFormat.format(date).toString();
		String sRequredDate=str.replace(str.charAt(2), ',');
		return sRequredDate.trim();
		
	}

}
