package spot.QA.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileHandling {
	



	public static String getPropertyValue(String param, String path) {
		String urlvalue =null;
		try {
			Properties prop = new Properties();
			InputStream inputStream = new FileInputStream(path);
			prop.load(inputStream);
			 urlvalue = prop.getProperty(param).toString().trim();
			

		} catch (Exception e) {

		}
		return urlvalue;
	}

}
