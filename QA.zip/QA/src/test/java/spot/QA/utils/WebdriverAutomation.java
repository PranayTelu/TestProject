package spot.QA.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebdriverAutomation {
	public static  final int MAX_WAIT_TIME_SECONDS=40;
	public static final String CONFIG_FILE_PATH="src/test/resources/config.properties";
	static WebDriver driver=null;
	public static WebDriver getWebDriver(String sBRowserName){
		 
		try{
		if(sBRowserName.equalsIgnoreCase("firefox")){
		System.setProperty("webdriver.gecko.driver", PropertyFileHandling.getPropertyValue("SERVER_DRIVER_FIREFOX",CONFIG_FILE_PATH));
		driver = new FirefoxDriver();
		}
		else if(sBRowserName.equalsIgnoreCase("chrome"))
		{
			DesiredCapabilities cap = DesiredCapabilities.chrome();

			cap.setJavascriptEnabled(true);
		System.setProperty("webdriver.chrome.driver", PropertyFileHandling.getPropertyValue("SERVER_DRIVER_CHROME",CONFIG_FILE_PATH));
		driver = new ChromeDriver(cap);
		}
		else if(sBRowserName.equalsIgnoreCase("ie"))
		{
			DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
			cap.setJavascriptEnabled(true);
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", PropertyFileHandling.getPropertyValue("SERVER_DRIVER_IE",CONFIG_FILE_PATH));
		driver = new InternetExplorerDriver(cap);
		}
		
		else if(sBRowserName.equalsIgnoreCase("edge"))
		{
			DesiredCapabilities cap = DesiredCapabilities.edge();
			cap.setJavascriptEnabled(true);
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.edge.driver", PropertyFileHandling.getPropertyValue("SERVER_DRIVER_EDGE",CONFIG_FILE_PATH));
		driver = new EdgeDriver(cap);
		}
		
		
		}
		catch(Exception e){
			System.out.println("Exception in Creation the Web Driver : "+e.getMessage());
		}
		return driver;
	}
	
	public static void waitForElement( WebElement  ele){
		
		
		try{
		WebDriverWait wait = new WebDriverWait(driver, MAX_WAIT_TIME_SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(ele));
		}
		catch(Exception exp){
			System.out.println(exp.getMessage()+" for xpath "+ele);
		}
	}

	

}
